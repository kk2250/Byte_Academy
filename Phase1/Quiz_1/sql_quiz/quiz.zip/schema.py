import csv
from database import Database

with Database('TSLA.db') as db:
    db.create_table('TSLA')
    db.ass_column('TSLA', 'open')
    db.ass_column('TSLA', 'high')
    db.ass_column('TSLA', 'low')
    db.ass_column('TSLA', 'closes')
    db.ass_column('TSLA', 'adj_close') 
    db.ass_column('TSLA', 'volume')
    with open('TSLA.csv', 'r') as file:
        rows = csv.reader(file)
        for row in rows:
            db.add_row(row)